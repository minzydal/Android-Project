package com.example.assignment3;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Binder;
import android.os.Build;
import android.os.IBinder;
import java.io.File;
import java.io.IOException;


public class MyService extends Service {

    private final IBinder mBinder = new MusicPlayerBinder();
    MediaPlayer mp;
    int media_position; // 곡 현재 위치 (for pause button and replay)

    //노티피케이션 관련 객체 생성
    NotificationManager notificationManager;
    NotificationChannel mChannel;
    Notification noti;
    Notification.Builder notiBuilder;

    @Override
    public IBinder onBind(Intent intent) {
        mp.start();
        return mBinder;
    }

        @Override
        public boolean onUnbind(Intent intent) {
            return false;
        }

    @Override
    public void onCreate() {
        super.onCreate();

        mp = new MediaPlayer(); // 미디어플레이어 객체 생성
        mp.setLooping(false); // 반복재생 여부

            if (Build.VERSION.SDK_INT >= 26) {
                mChannel = new NotificationChannel("music_service_channel_id",
                        "music_service_channel",
                        NotificationManager.IMPORTANCE_HIGH);
                mChannel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
                //노티피케이션 매니저 초기화
                notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                //노티피케이션 채널 생성
                notificationManager.createNotificationChannel(mChannel);
                //노티피케이션 빌더 객체 생성
                notiBuilder = new Notification.Builder(this, mChannel.getId());
            } else {
                //노티피케이션 빌더 객체 생성
                notiBuilder = new Notification.Builder(this);
            }

            Intent intent = new Intent(this, MainActivity.class);
            PendingIntent pIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);

            noti = notiBuilder.setContentTitle("Music Player")
                    .setContentText("Music player is currently running")
                    .setSmallIcon(R.mipmap.ic_launcher)
                    .setContentIntent(pIntent)
                    .setDefaults(Notification.DEFAULT_VIBRATE)
                    .build();

            //foreground service설정
            startForeground(123, noti);

            mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp) {
                    stopSelf();
                }
            });
        }


    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        // mediaplayer 가 null이거나 Playing 중이 아니면 재생
        if (mp != null && !mp.isPlaying()) {

            try {
                //String rmp3 = intent.getStringExtra("selectedMP3");
                Uri ruri = intent.getParcelableExtra("play");
                File rfile = new File(ruri.toString(), "악동뮤지션_매력있어.mp3"); // 재생할 음악 경로와 이름
                mp = new MediaPlayer();
                mp.setDataSource(rfile.getPath()); // 파일경로 불러오기
                mp.prepare();
                mp.start();
                mp.seekTo(media_position);
            } catch (IOException e) {
                e.printStackTrace();
            }

        } else if(mp != null && mp.isPlaying()) {
           //mp = MediaPlayer.create(getApplicationContext(), array[index]);
            mp.pause();
            media_position = mp.getCurrentPosition(); // 현재 위치 받아오기 to replay
        }
        return START_STICKY;
    }
/*
 // 다음곡 재생
    public void skipnext(){
        Intent intent = new Intent();
        String rselect = intent.getStringExtra("selectedMP3");
        try{
            mp = new MediaPlayer();

        }

        for(int i = 0 ; i < rselect.length(); i++){

        }
        mp.start();
    }
/*
 // 리스트뷰에 있는 아이템 클릭 시 재생할 함수
    public void onItemClick(){
        Intent intent = new Intent();
        String rselect = intent.getStringExtra("selectedMP3");

        try {
            mp = new MediaPlayer();
            mp.setDataSource(rselect);
            mp.prepare();
            mp.start();

        }catch(IOException e){
            e.printStackTrace();
        }
    }

*/
    @Override
    public void onDestroy() {
        super.onDestroy();
        //MediaPlayer play 중지
        if (mp.isPlaying()) {
            //MediaPlayer 객체 해제
            mp.stop();
        }
        mp.release();
    }

    public class MusicPlayerBinder extends Binder {
        public MyService getService() {
            return MyService.this;
        }
    }
}
