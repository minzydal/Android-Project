package com.example.assignment3;
import android.Manifest;
import android.app.IntentService;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.IBinder;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import java.io.File;
import java.util.ArrayList;


public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    MediaPlayer mp;
    int click = 0; // 재생버튼 클릭 횟수
    TextView mTitle; // 재생중인 곡 제목
    Intent intentService;
    ArrayList<String> playlist; // 음악리스트를 받아올 리스트 생성
    ArrayAdapter<String> musicList; // 리스트어댑터
    String folderPath;
    File testlist;
    private int currentPosition = 0;

    String selectedMP3; // 선택한 곡

    private static final int MY_PERMISSIONS_REQUEST_WRITE_EXTERNAL_STORAGE = 1;
    boolean isPermitted = false;
    ImageButton btnplay; //재생버튼
    ImageButton btnnext; //다음 곡 재생 버튼
    ImageButton btnprev; //이전 곡 재생 버튼

    ListView lv1; // 리스트뷰

    private MyService mservice; // 서비스 클래스
    boolean mBound = false;

    // 서비스 커넥션 선언
    private ServiceConnection mConnection = new ServiceConnection() {

        // 서비스 연결
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {

            MyService.MusicPlayerBinder binder = (MyService.MusicPlayerBinder) service;
            mservice = binder.getService();
            mBound = true;
        }

        // 서비스 비정상적 종료
        @Override
        public void onServiceDisconnected(ComponentName name) {
            mservice = null;
        }


    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("MUSIC APP");

        requestRuntimePermission();

        intentService = new Intent(this, MyService.class);
        playlist = new ArrayList<>();


        // mp3파일 경로 불러오기
        testlist = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC);
        folderPath = testlist.getAbsolutePath();


        // 파일 새로 생성 후 mp3 파일 이름 받아서 listview에 출력하기
        final File[] listFiles = new File(folderPath).listFiles();
        for (File file : listFiles) {
            final String fileName, extName;
            fileName = file.getName();
            extName = fileName.substring(fileName.length() - 3);
            if (extName.equals("mp3")) {
                playlist.add(fileName);
            }
        }

        musicList = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, playlist);

        lv1 = findViewById(R.id.lv1);
        lv1.setAdapter(musicList);
        lv1.setItemChecked(0, true);

        lv1.setOnItemClickListener(
                new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        currentPosition = position;
                        selectedMP3 = playlist.get(position);
                        btnplay.setImageResource(R.drawable.pause);
                    }
                });
        selectedMP3 = playlist.get(0);

        mTitle = findViewById(R.id.title);
        btnplay = findViewById(R.id.play);
        btnnext = findViewById(R.id.skipnext);
        btnprev = findViewById(R.id.skipprevious);
        btnplay.setOnClickListener(this);
        btnnext.setOnClickListener(this);
        btnprev.setOnClickListener(this);
    }


    @Override
    public void onClick(View v) {

        if (v.equals(btnplay)) {
            click = 1 - click; // 일시정지버튼과 재생버튼을 번갈아가며 화면에 출력
            mTitle.setText(selectedMP3);
            Intent intent = new Intent(intentService);

            switch (click) {

                case 1:

                    //Intent intent = new Intent(intentService);
                    File file = new File(String.valueOf(testlist)); // 위에서 정의한 파일 경로
                    Uri uri = Uri.fromFile(file);
                    intent.putExtra("play", uri);
                    btnplay.setImageResource(R.drawable.pause); // 이미지버튼만 pause로 바꿔줌
                    startService(intent);
                    break;

                case 0:

                    btnplay.setImageResource(R.drawable.play); // 이미지 버튼 다시 play로 바꿔줌
                    startService(intentService);
                    break;
            }
        }

        if (v.equals(btnnext)) {

        }
    }

    /*
        public void playMusic(){
            File file = new File("/storage/emulated/0/Music/악동뮤지션_매력있어.mp3");
            Intent intent = new Intent(intentService);
            Uri uri = Uri.fromFile(file);
            intent.setDataAndType(uri, "audio/*");
            startService(intent);
    }*/

/*
        btnnext = findViewById(R.id.skipnext);
        btnnext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startService(intentService);
            }
        });

        btnprev = findViewById(R.id.skipprevious);
        btnprev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startService(intentService);
            }
        });

*/

    @Override
    //액션바 나타내기
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.actionbar_actions, menu);
        return true;
    }


    @Override
    //액션바 액션 정의
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.terminate) {
            stopService(intentService);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

// request permission
    private void requestRuntimePermission() {

        if (ContextCompat.checkSelfPermission(MainActivity.this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != getPackageManager().PERMISSION_GRANTED) {

            if (ActivityCompat.shouldShowRequestPermissionRationale(MainActivity.this,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE)) {

            } else {
                ActivityCompat.requestPermissions(MainActivity.this,
                        new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                        MY_PERMISSIONS_REQUEST_WRITE_EXTERNAL_STORAGE);
            }
        } else {
            isPermitted = true;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_WRITE_EXTERNAL_STORAGE: {
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    isPermitted = true;
                } else {
                    isPermitted = false;
                }
                return;
            }
        }
    }
}


